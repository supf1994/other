

target("libtest")
    set_kind("static")

    add_files("interface.cpp")
    add_headerfiles("interface.h")


