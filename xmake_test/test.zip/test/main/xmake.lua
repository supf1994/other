

target("test_demo")
    set_kind("binary")
    add_deps("libtest")
    add_includedirs("../libtest")

    add_files("main.cpp")
    add_headerfiles("interface.h")
